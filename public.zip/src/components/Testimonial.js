import Carousel from 'react-bootstrap/Carousel';
function UncontrolledExample() {
    return (
        <div >
         <div className="section-tittle text-center">
        <h2>What Client Say About Us</h2>
        </div>
      <Carousel variant="dark">
        <Carousel.Item>
        <div className="single-testimonial text-center">
                  <div className="testimonial-caption ">
                    <div className="testimonial-top-cap">
                      <p style={{fontSize: 20, marginLeft: "20%", marginRight: "20%"}}>
                        I was looking for a digital marketing team who could
                        manage my website. Finally, I met Ageskill’s team now my
                        website’s ranking is at a higher level. If you want top
                        rank on search engine than Ageskill will give you the
                        best digital marketing service for your website.{" "}
                      </p>
                    </div>
                    {/* founder */}
                    <div className="testimonial-founder d-flex align-items-center justify-content-center">
                      <div className="founder-text testimonial-area testimonial-main">
                        <span style={{fontSize: 25, llineHeight: 38, fontWeight: 600, color: "#2e1088"}}>Mohit Thapliyal</span>
                        <p>KamyasEnterprises</p>
                      </div>
                    </div>
                  </div>
                </div>
        </Carousel.Item>
        <Carousel.Item>
        <div className="single-testimonial text-center">
                  <div className="testimonial-caption ">
                    <div className="testimonial-top-cap">
                      <p style={{fontSize: 20, marginLeft: "20%", marginRight: "20%"}}>
                        Ageskill has the best talent of website design,
                        development and digital marketing, that’s why Ageskill
                        designs your website according to your client’s
                        behaviour. I recommend all who started their own
                        business take Ageskill’s services.{" "}
                      </p>
                    </div>
                    {/* founder */}
                    <div className="testimonial-founder d-flex align-items-center justify-content-center">
                      <div className="founder-text">
                        <span style={{fontSize: 25, llineHeight: 38, fontWeight: 600, color: "#2e1088"}}>Abhishek 
                        Sagar</span>
                        <p>MKGRAPHICS</p>
                      </div>
                    </div>
                  </div>
                </div>
        </Carousel.Item>
      </Carousel>
      </div>
    );
  }
  
  export default UncontrolledExample;