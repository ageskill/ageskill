import React from 'react'
import '../assets/css/bootstrap.min.css'
import '../assets/css/flaticon.css'
import '../assets/css/slicknav.css'
import '../assets/css/animate.min.css'
import '../assets/css/magnific-popup.css'
import '../assets/css/fontawesome-all.min.css'
import '../assets/css/themify-icons.css'
import '../assets/css/slick.css'
import '../assets/css/nice-select.css'
import '../assets/css/style.css'
import '../assets/css/flaticon.css'
import '../assets/as_market_icon/font/as_market_icon.css'
import '../assets/as_web_icon/font/as_web_icon.css'
import '../assets/as_seo_icon/font/as_seo_icon.css'
import '../assets/as_des_icon/font/as_des_icon.css'

export default function Service() {
  return (
    <div>
  <main>
       <div className="services-area">
           <div className="container">

            
               <div className="row d-flex justify-content-center">
                   <div className="col-lg-8">
                       <div className="section-tittle text-center mb-80">
                           <span>Services</span>
                           <h2>What Will You Get In Our Digital Marketing Service?</h2>
                       </div>
                   </div>
               </div>
           </div>
       </div>
     
       <div className="what-we-do">
           <div className="container">
               <div className="row">
                   <div className="col-lg-4 col-md-6">
                       <div className="single-do text-center mb-30">
                           <div className="do-icon">
                               <span  className="as_seo_icon-024-link" />
                           </div>
                           <div className="do-caption">
                               <h4>Link Building</h4>
   
                           </div>
                           <div className="do-btn">
                               <a href="#"><i className="ti-arrow-right"></i> get started</a>
                           </div>
                       </div>
                   </div>
                    <div className="col-lg-4 col-md-6">
                       <div className="single-do active text-center mb-30">
                           <div className="do-icon">
                               <span  className="as_seo_icon-003-content-writing" />
                           </div>
                           <div className="do-caption">
                               <h4>Content marketing</h4>
                               
                           </div>
                           <div className="do-btn">
                               <a href="#"><i className="ti-arrow-right"></i> get started</a>
                           </div>
                       </div>
                   </div>
                    <div className="col-lg-4 col-md-6">
                       <div className="single-do text-center mb-30">
                           <div className="do-icon">
                               <span  className="as_seo_icon-035-seo" />
                           </div>
                           <div className="do-caption">
                               <h4>On Page SEO</h4>
                               
                           </div>
                           <div className="do-btn">
                               <a href="#"><i className="ti-arrow-right"></i> get started</a>
                           </div>
                       </div>
                   </div> <div className="col-lg-4 col-md-6">
                       <div className="single-do active text-center mb-30">
                           <div className="do-icon">
                               <span  className="as_des_icon-customer-reviews" />
                           </div>
                           <div className="do-caption">
                               <h4>Chatbot</h4>
                               
                           </div>
                           <div className="do-btn">
                               <a href="#"><i className="ti-arrow-right"></i> get started</a>
                           </div>
                       </div>
                   </div>
                    <div className="col-lg-4 col-md-6">
                       <div className="single-do text-center mb-30">
                           <div className="do-icon">
                               <span  className="flaticon-social-media-marketing"></span>
                           </div>
                           <div className="do-caption">
                               <h4>Social Media Marketing</h4>
                              
                           </div>
                           <div className="do-btn">
                               <a href="#"><i className="ti-arrow-right"></i> get started</a>
                           </div>
                       </div>
                   </div>
                    <div className="col-lg-4 col-md-6">
                       <div className="single-do active text-center mb-30">
                           <div className="do-icon">
                               <span  className="as_seo_icon-033-search-engine"></span>
                           </div>
                           <div className="do-caption">
                               <h4>Offline SEO</h4>
                               
                           </div>
                           <div className="do-btn">
                               <a href="#"><i className="ti-arrow-right"></i> get started</a>
                           </div>
                       </div>
                   </div>
                   <div className="col-lg-4 col-md-6">
                       <div className="single-do text-center mb-30">
                           <div className="do-icon">
                               <span  className="as_seo_icon-021-keywords"></span>
                           </div>
                           <div className="do-caption">
                               <h4>Keywords Research</h4>
   
                           </div>
                           <div className="do-btn">
                               <a href="#"><i className="ti-arrow-right"></i> get started</a>
                           </div>
                       </div>
                   </div>
                   <div className="col-lg-4 col-md-6">
                       <div className="single-do active text-center mb-30">
                           <div className="do-icon">
                               <span  className="as_seo_icon-022-analytics"></span>
                           </div>
                           <div className="do-caption">
                               <h4>Analytics</h4>
   
                           </div>
                           <div className="do-btn">
                               <a href="#"><i className="ti-arrow-right"></i> get started</a>
                           </div>
                       </div>
                   </div>
                   <div className="col-lg-4 col-md-6">
                       <div className="single-do text-center mb-30">
                           <div className="do-icon">
                               <span  className="flaticon-tasks"></span>
                           </div>
                           <div className="do-caption">
                               <h4>Lead Generation</h4>
   
                           </div>
                           <div className="do-btn">
                               <a href="#"><i className="ti-arrow-right"></i> get started</a>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
   
       <div className="generating-area visite-padding2 choose-best">
           <div className="container">
              
                <div className="row d-flex justify-content-center">
                   <div className="col-lg-8">
                       <div className="section-tittle text-center">
                           <h2>What Will You Get In Our Web Development Service?</h2>
                       </div>
                   </div>
               </div>
               <div className="row">
                   <div className="col-lg-6 col-md-6">
                       <div className="single-generating d-flex mb-30">
                           <div className="generating-icon">
                               <span className="as_web_icon-019-login"></span>
                           </div>
                           <div className="generating-cap">
                               <h4>Business Websites</h4>
                               <p>Unlimited web design, user login/registration pages, business account, free Domain and SSL certification with hosting service.</p>
                           </div>
                       </div>
                   </div> 
                   <div className="col-lg-6 col-md-6">
                       <div className="single-generating d-flex mb-30">
                           <div className="generating-icon">
                               <span className="as_web_icon-034-online-shop"></span>
                           </div>
                           <div className="generating-cap">
                               <h4>E-commerce Websites</h4>
                               <p>Unlimited web design, user login/registration pages, product pages, checkout page and hosting service.</p>
                           </div>
                       </div>
                   </div>
                   <div className="col-lg-6 col-md-6">
                       <div className="single-generating d-flex mb-30">
                           <div className="generating-icon">
                               <span className="as_web_icon-018-html"></span>
                           </div>
                           <div className="generating-cap">
                               <h4>Full Stack Development</h4>
                               <p>Ageskill provides mobile responsive full stack development services with database management.</p>
                           </div>
                       </div>
                   </div>
                   <div className="col-lg-6 col-md-6">
                       <div className="single-generating d-flex mb-30">
                           <div className="generating-icon">
                               <span className="as_web_icon-004-coding"></span>
                           </div>
                           <div className="generating-cap">
                               <h4>Wordpress Websites</h4>
                               <p>We play with wordpress themes and plugins very easily. We are familior with all page builders.</p>
                           </div>
                       </div>
                   </div>
                    <div className="col-lg-6 col-md-6">
                       <div className="single-generating d-flex mb-30">
                           <div className="generating-icon">
                               <span className="as_des_icon-web-links"></span>
                           </div>
                           <div className="generating-cap">
                               <h4>Applications Integration</h4>
                               <p>We play with other websites and applications integration like zoho one, mailchimp, wordpress, hubspot, etc.</p>
                           </div>
                       </div>
                   </div>
                    <div className="col-lg-6 col-md-6">
                       <div className="single-generating d-flex mb-30">
                           <div className="generating-icon">
                               <span className="as_des_icon-web-development-1"></span>
                           </div>
                           <div className="generating-cap">
                               <h4>Management Service</h4>
                               <p>Ageskill provides fully management service, we design, host and website integration with crm and other applications.</p>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>
  
       <div className="have-project">
           <div className="container">
               <div className="haveAproject"  data-background="assets/img/team/have.jpg">
                   <div className="row d-flex align-items-center">
                       <div className="col-xl-7 col-lg-9 col-md-12">
                           <div className="wantToWork-caption">
                               <h2>Promote your business</h2>
                               <p>Connect with us and get your URL to promote your business online without any cost. Offer for a limited time only.</p>
                           </div>
                       </div>
                       <div className="col-xl-5 col-lg-3 col-md-12">
                           <div className="wantToWork-btn f-right">
                               <a href="https://remotework.ageskill.net/registration-to-promote-your-business/" className="btn btn-ans">Subscribe Now</a>
                           </div>
                       </div>
                   </div>
               </div>
               
           </div>
       </div>
    

   </main>

    </div>
  )
}
