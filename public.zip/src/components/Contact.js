import React from 'react'
import '../assets/css/bootstrap.min.css'
import '../assets/css/flaticon.css'
import '../assets/css/slicknav.css'
import '../assets/css/animate.min.css'
import '../assets/css/magnific-popup.css'
import '../assets/css/fontawesome-all.min.css'
import '../assets/css/themify-icons.css'
import '../assets/css/slick.css'
import '../assets/css/nice-select.css'
import '../assets/css/style.css'

export default function Contact() {
  return (
    <div>
      <div className="services-area">
        <div className="container">
            <div className="row d-flex justify-content-center">
                <div className="col-lg-8">
                    <div className="section-tittle text-center mb-80">
                        <span>Contact</span>
                        <h2>Contact Us​</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section className="contact-section">
            <div className="container">
              
    
    
                <div className="row">
                    <div className="col-12">
                        <h2 className="contact-title">Get in Touch</h2>
                    </div>
                    <div className="col-lg-8">
                       <form id="add-user-form">
                            <div className="row">
                                <div className="col-12">
                                    <div className="form-group">
                                        <textarea className="form-control w-100" name="message" id="message" cols="30" rows="9" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Message'" placeholder=" Enter Message"></textarea>
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        <input className="form-control valid" name="name" id="name" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your name'" placeholder="Enter your name" />
                                    </div>
                                </div>
                                <div className="col-sm-6">
                                    <div className="form-group">
                                        
                                        <input className="form-control valid" name="email" id="email" type="email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email address'" placeholder="Email" />
                                    </div>
                                </div>
                                <div className="col-12">
                                    <div className="form-group">
                                        <input className="form-control valid" name="subject" id="subject" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Subject'" placeholder="Enter Subject" />
                                    </div>
                                </div>
                            </div>
                            <div className="form-group mt-3">
                                <button type="submit" name="submit" className="button button-contactForm boxed-btn">Send</button>
                            </div>
                        </form>
             
      </div>
                    <div className="col-lg-3 offset-lg-1">
                        <div className="media contact-info">
                            <span className="contact-info__icon"><i className="ti-home"></i></span>
                            <div className="media-body">
                                <h3>116/117 3rd F, Sector 3</h3>
                                <p>Vaishali Ghaziabad 201010</p>
                            </div>
                        </div>
                        <div className="media contact-info">
                            <span className="contact-info__icon"><i className="ti-tablet"></i></span>
                            <div className="media-body">
                                <h3>8750897310</h3>
                                <p>Mon to Fri 9am to 6pm</p>
                            </div>
                        </div>
                        <div className="media contact-info">
                            <span className="contact-info__icon"><i className="ti-email"></i></span>
                            <div className="media-body">
                                <h3>info@ageskill.net</h3>
                                <p>Send us your query anytime!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
  
         <div className="have-project pt-50">
            <div className="container">
                <div className="haveAproject"  data-background="assets/img/team/have.jpg">
                    <div className="row d-flex align-items-center">
                        <div className="col-xl-7 col-lg-9 col-md-12">
                            <div className="wantToWork-caption">
                                <h2>Promote your business</h2>
                                <p>Connect with us and get your URL to promote your business online without any cost. Offer for a limited time only.</p>
                            </div>
                        </div>
                        <div className="col-xl-5 col-lg-3 col-md-12">
                           <div className="wantToWork-btn f-right">
                                <a href="https://remotework.ageskill.net/registration-to-promote-your-business/" className="btn btn-ans">Subscribe Now</a>
                           </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
  )
}
