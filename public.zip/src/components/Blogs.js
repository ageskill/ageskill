import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCode, faFileCode } from '@fortawesome/free-solid-svg-icons'
import '../assets/css/bootstrap.min.css'
import '../assets/css/flaticon.css'
import '../assets/css/slicknav.css'
import '../assets/css/animate.min.css'
import '../assets/css/magnific-popup.css'
import '../assets/css/fontawesome-all.min.css'
import '../assets/css/themify-icons.css'
import '../assets/css/slick.css'
import '../assets/css/nice-select.css'
import '../assets/css/style.css'
import { BrowserRouter as Router, Route, Link, Switch} 
        from "react-router-dom";


class BlogApp extends React.Component {
   
    // Constructor 
    constructor(props) {
        super(props);
   
        this.state = {
            items: [],
            DataisLoaded: false
        };
    }
   
    // ComponentDidMount is used to
    // execute the code 
    componentDidMount() {
        fetch(
"https://remotework.ageskill.net/wp-json/wp/v2/posts")
            .then((res) => res.json())
            .then((json) => {
                this.setState({
                    items: json,
                    DataisLoaded: true
                });
            })
    }
    render() {
        const { DataisLoaded, items } = this.state;
        if (!DataisLoaded) return <div>
            <h4 style={{textAlign: "center", marginTop: "5%"}}> Pleses wait some time.... </h4> </div> ;
   
        return (
        <div className = "App">
 <div className="what-we-do we-padding">
      <div className="container">
        {/* Section-tittle */}
        <div className="row d-flex justify-content-center">
          <div className="col-lg-8">
            <div className="section-tittle text-center">
              <h2>Our Blogs​</h2>
            </div>
          </div>
        </div>
        <div className="row">
          
            {
                items.map((item) => ( 
                
                    <div className="col-lg-4 col-md-6">
                    <div className="single-do text-center mb-30" key={item.id}>
                    <div className="tips-img">
                    <a href={item.link} target="blank">
             <img src={item.jetpack_featured_media_url} style={{ width: 370, height: 200, borderRadius: 10}} alt /></a>
              </div>
                    <div className="tips-caption">
                    <a href={item.link} target="blank">
                <h4 style={{ width: 370, fontWeight: 700, textAlign: 'left'}}>{ item.title.rendered }</h4>
                </a>
               <p style={{ width: 370,textAlign: 'left'}}>{item.excerpt.rendered}</p> 
              </div>
                    <div className="do-btn" style={{ textAlign: 'left'}}>
                <a href={item.link} target="blank">
                  <i className="ti-arrow-right" /> read more
                </a>
              </div>
            </div>
            </div>
                    
                    
                ))
            }
             
              
             
            </div>
          </div>
         </div>
      </div>
 
    );
}
}
   
export default BlogApp;