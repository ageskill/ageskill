import React from 'react'
import '../assets/css/bootstrap.min.css'
import '../assets/css/flaticon.css'
import '../assets/css/slicknav.css'
import '../assets/css/animate.min.css'
import '../assets/css/magnific-popup.css'
import '../assets/css/fontawesome-all.min.css'
import '../assets/css/themify-icons.css'
import '../assets/css/slick.css'
import '../assets/css/nice-select.css'
import '../assets/css/style.css'
import HomeBlog from   './BlogHome'
import Testimonial from   './Testimonial'
import Serivebg from '../assets/img/service/we-create.png'

export default function Price() {
  return (
    <div>
    <main>
     
        <div className="slider-area">
            <div className="slider-active">
                <div className="single-slider slider-height d-flex align-items-center">
                    <div className="container">
                        <div className="row d-flex align-items-center">
                            <div className="col-lg-5 d-none d-xl-block">
                                <div className="hero__img hero__img2 " data-animation="fadeInLeft" data-delay="1s">
                                <img src={Serivebg} alt />
                                </div>
                            </div>
                            <div className="col-lg-7 col-md-9 ">
                                <div className="hero__caption hero__caption2">
                                    <h1 data-animation="fadeInRight" data-delay=".4s">Get Management Service</h1>
                                    <p data-animation="fadeInRight" data-delay=".6s">We offer, web pages design, hosting management, lead generation, crm and other applications integration etc.</p>
                                   
                                    <div className="hero__btn" data-animation="fadeInRight" data-delay=".8s">
                                        <a href="/services" className="btn hero-btn">Know More</a>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div className="about-shape">
                <div className="shape-left">
                    <img src="assets/img/hero/about_shape1.png" alt="" />
                </div>
                <div className="shape-right">
                    <img src="assets/img/hero/about-sharpe2.png" alt="" />
                </div>
            </div>
        </div>
        <div className="choose-best choose-padding">
            <div className="container">
             
                <div className="row d-flex justify-content-center">
                    <div className="col-lg-7">
                        <div className="section-tittle text-center">
                            <h2>Web Development Plan</h2>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-lg-4 col-md-6">
                        <div className="single-choose text-center mb-30">
                            <div className="do-icon">
                                <span  className="flaticon-project"></span>
                            </div>
                            <div className="do-caption">
                            	<h3>Startup Plan</h3>
                                <h4>₹ 11,999</h4>
                                <ul>
                                    <li>5 Web Pages</li>
                                    <li>Basic SEO</li>
                                    <li>3 Query Form</li>
                                    <li>One Month Maintenance</li>
                                    <li><div className="do-btn">
                                <b><a href="#">Get Now</a></b>
                            </div></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                     <div className="col-lg-4 col-md-6">
                        <div className="single-choose active text-center mb-30">
                            <div className="do-icon">
                                <span  className="flaticon-award"></span>
                            </div>
                            <div className="do-caption">
                            	<h3>Advance Plan</h3>
                                <h4>14,999</h4>
                                <ul>
                                    <li>Business Website</li>
                                    <li>CRM Integration</li>
                                    <li>Blogging Page</li>
                                    <li>One Month Maintenance</li>
                                    <li><div className="do-btn">
                                <b><a href="#">Get Now</a></b>
                            </div></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                     <div className="col-lg-4 col-md-6">
                        <div className="single-choose text-center mb-30">
                            <div className="do-icon">
                                <span  className="as_des_icon-finger-touch-screen"></span>
                            </div>
                            <div className="do-caption">
                            	<h3>Premium Plan</h3>
                                <h4>₹ 19,999</h4>
                                <ul>
                                    <li>E-commerce Website</li>
                                    <li>Product Pages</li>
                                    <li>Payment Gateway Page</li>
                                    <li>One Month Maintenance</li>
                                    <li><div className="do-btn">
                                <b><a href="#">Get Now</a></b>
                            </div></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
        <div className="choose-best choose-padding">
            <div className="container">
               
                <div className="row d-flex justify-content-center">
                    <div className="col-lg-7">
                        <div className="section-tittle text-center">
                            <h2>Digital Markeing Plan</h2>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-lg-4 col-md-6">
                        <div className="single-choose text-center mb-30">
                            <div className="do-icon">
                                <span  className="flaticon-project"></span>
                            </div>
                            <div className="do-caption">
                            	<h3>Startup Plan</h3>
                                <h4>₹ 7,999</h4>
                                <ul>
                                    <li>On Page SEO</li>
                                    <li>Keywords Research</li>
                                    <li>Link Building</li>
                                    <li>Analytics</li>
                                    <li><div className="do-btn">
                                <b><a href="#">Get Now</a></b>
                            </div></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                     <div className="col-lg-4 col-md-6">
                        <div className="single-choose active text-center mb-30">
                            <div className="do-icon">
                                <span  className="flaticon-award"></span>
                            </div>
                            <div className="do-caption">
                            	<h3>Advance Plan</h3>
                                <h4>₹ 14,999</h4>
                                <ul>
                                    <li>Startup Feature Included</li>
                                    <li>Social Media Marketing</li>
                                    <li>Chatboat</li>
                                    <li>Lead Generation</li>
                                    <li><div className="do-btn">
                                <b><a href="#">Get Now</a></b>
                            </div></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                     <div className="col-lg-4 col-md-6">
                        <div className="single-choose text-center mb-30">
                            <div className="do-icon">
                                <span  className="as_des_icon-finger-touch-screen"></span>
                            </div>
                            <div className="do-caption">
                            	<h3>Premium Plan</h3>
                                <h4>₹ 24,999</h4>
                                <ul>
                                    <li>Advance Feature Included</li>
                                    <li>Offline SEO</li>
                                    <li>Content Management</li>
                                    <li>One Month Support</li>
                                    <li><div className="do-btn">
                                <b><a href="#">Get Now</a></b>
                            </div></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className="choose-best choose-padding">
            <div className="container">
             
                <div className="row d-flex justify-content-center">
                    <div className="col-lg-7">
                        <div className="section-tittle text-center">
                            <h2>Our Most Popular Pricing Plan </h2>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-lg-4 col-md-6">
                        <div className="single-choose text-center mb-30">
                            <div className="do-icon">
                                <span  className="as_web_icon-033-web-hosting"></span>
                            </div>
                            <div className="do-caption">
                                <h4>₹ 9,999</h4>
                                <ul>
                                    <li>Free Domain Registration</li>
                                    <li>One Year Web Hosting</li>
                                    <li>Upto 5 Web Pages</li>
                                    <li>One Query Form</li>
                                    <li><div className="do-btn">
                                <b><a href="#">Get Now</a></b>
                            </div></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                     <div className="col-lg-4 col-md-6">
                        <div className="single-choose active text-center mb-30">
                            <div className="do-icon">
                                <span className="as_web_icon-032-web-design-1"></span>
                            </div>
                            <div className="do-caption">
                                <h4>₹ 14,999</h4>
                                <ul>
                                    <li>Business Website</li>
                                    <li>Basic SEO</li>
                                    <li>Blogging Page</li>
                                    <li>One Month Maintenance</li>
                                     <li><div className="do-btn">
                                <b><a href="#">Get Now</a></b>
                            </div></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                     <div className="col-lg-4 col-md-6">
                        <div className="single-choose text-center mb-30">
                            <div className="do-icon">
                                <span  className="as_web_icon-034-online-shop"></span>
                            </div>
                            <div className="do-caption">
                                <h4>₹ 24,999</h4>
                                <ul>
                                    <li>E-commerce Website</li>
                                    <li>Basic SEO</li>
                                    <li>Unlimited Product Pages</li>
                                    <li>Two Month Maintenance</li>
                                    <li><div className="do-btn">
                                <a href="#">Get Now</a>
                            </div></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <Testimonial />
    <HomeBlog/>                    

    </main>
    </div>
  )
}