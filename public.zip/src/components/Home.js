import React from 'react'
import '../assets/css/bootstrap.min.css'
import '../assets/css/slicknav.css'
import '../assets/css/animate.min.css'
import '../assets/css/magnific-popup.css'
import '../assets/css/fontawesome-all.min.css'
import '../assets/css/themify-icons.css'
import '../assets/css/slick.css'
import '../assets/css/flaticon.css'
import '../assets/as_market_icon/font/as_market_icon.css'
import '../assets/as_web_icon/font/as_web_icon.css'
import '../assets/css/nice-select.css'
import '../assets/css/style.css'
import Heroright from '../assets/img/hero/hero_right.png'
import Serivebg from '../assets/img/service/we-create.png'
import Herorback from '../assets/img/hero/h1_hero.png'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCode, faFileCode } from '@fortawesome/free-solid-svg-icons'
import digoptimg from '../assets/img/visit/visit_1.jpg'
import digseoimg from '../assets/img/visit/visit_2.jpg'
import diganaimg from '../assets/img/visit/visit_3.jpg'
import diglinkgimg from '../assets/img/visit/visit_4.jpg'
import subscribeimg from '../assets/img/team/have.jpg'
import HomeBlog from   './BlogHome'
import Testimonial from   './Testimonial'

export default function Home() {
  return (
    <div>
      
      <main>
    {/* Slider Area Start*/}
    <div className="slider-area ">
      <div className="slider-active">
        <div
          className="single-slider slider-height d-flex align-items-center"
          style={{ 
            backgroundImage: `url(${Herorback})` 
          }}
        >
          <div className="container">
            <div className="row d-flex align-items-center">
              <div className="col-lg-7 col-md-9 ">
                <div className="hero__caption">
                  <h1 data-animation="fadeInLeft" data-delay=".4s">
                    Welcome
                    <br />
                    To The Ageskill
                  </h1>
                  <p data-animation="fadeInLeft" data-delay=".6s">
                    Ageskill provides digital marketing and web development
                    services. We also offer CRM &amp; other application
                    integration facilities.
                  </p>
              
                  {/* Hero-btn */}
                  <div
                    className="hero__btn"
                    data-animation="fadeInLeft"
                    data-delay=".8s"
                  >
                    <a href="#footer01" className="btn hero-btn">
                      Contact Us
                    </a>
                  </div>
                </div>
              </div>
              <div className="col-lg-5">
                <div
                  className="hero__img d-none d-lg-block"
                  data-animation="fadeInRight"
                  data-delay="1s"
                >
                  <img
                    src={Heroright}
                    alt="ageskill assests"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* Slider Area End*/}
    {/* What We do start*/}
    <div className="what-we-do we-padding">
      <div className="container">
        {/* Section-tittle */}
        <div className="row d-flex justify-content-center">
          <div className="col-lg-8">
            <div className="section-tittle text-center">
              <h2>Why Ageskill Is Best For Your Business​</h2>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-4 col-md-6">
            <div className="single-do text-center mb-30">
              <div className="do-icon">
                <span className="as_web_icon-027-speedometer"></span>
      
              </div>
              <div className="do-caption">
                <h4>Web Development Services</h4>
                <p>
                  Ageskill offers web design, development, and maintenance
                  services to grow your business
                </p>
              </div>
              <div className="do-btn">
                <a href="/services">
                  <i className="ti-arrow-right" /> read more
                </a>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
            <div className="single-do active text-center mb-30">
              <div className="do-icon">
                <span className="as_market_icon-social-network"></span>
              </div>
              <div className="do-caption">
                <h4>Digital Marketing Services</h4>
                <p>
                  Ageskill provides page optimization, social media marketing,
                  guest posting, and link building services
                </p>
              </div>
              <div className="do-btn">
                <a href="/services">
                  <i className="ti-arrow-right" /> read more
                </a>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
            <div className="single-do text-center mb-30">
              <div className="do-icon">
              <span  className="as_market_icon-devices"></span>
              </div>
              <div className="do-caption">
                <h4>Website Applications Integration</h4>
                <p>
                  We play with other websites and applications integration like
                  Zoho one, MailChimp, etc.
                </p>
              </div>
              <div className="do-btn">
                <a href="/services">
                  <i className="ti-arrow-right" /> read more
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* What We do End*/}
    {/* We Create Start */}
    <div className="we-create-area create-padding">
      <div className="container">
        <div className="row d-flex align-items-end">
          <div className="col-lg-6 col-md-12">
            <div className="we-create-img">
              <img src={Serivebg} alt />
            </div>
          </div>
          <div className="col-lg-6 col-md-12">
            <div className="we-create-cap">
              <h3>Some New Stuffs From Management Service</h3>
              <p>
                Ageskill provides full management service, we design, host, and
                website integration with CRM and other applications.
              </p>
              <a href="/services" className="btn">
                Read More
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* We Create End */}
    {/* Generating Start */}
    <div className="generating-area ">
      <div className="container">
        {/* Section-tittle */}
        <div className="row d-flex justify-content-center">
          <div className="col-lg-8">
            <div className="section-tittle text-center">
              <h2>Some New Stuffs From Web Development</h2>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-6 col-md-6">
            <div className="single-generating d-flex mb-30">
              <div className="generating-icon">
                <span className="as_web_icon-019-login" />
              </div>
              <div className="generating-cap">
                <h4>Business Websites</h4>
                <p>
                  Unlimited web design, user login/registration pages, business
                  account, free Domain, and SSL certification with hosting
                  service.
                </p>
              </div>
            </div>
          </div>
          <div className="col-lg-6 col-md-6">
            <div className="single-generating d-flex mb-30">
              <div className="generating-icon">
              <span className="as_web_icon-034-online-shop" />
              </div>
              <div className="generating-cap">
                <h4>E-commerce Websites</h4>
                <p>
                  Unlimited web design, user login/registration pages, product
                  pages, checkout page, and hosting service.
                </p>
              </div>
            </div>
          </div>
          <div className="col-lg-6 col-md-6">
            <div className="single-generating d-flex mb-30">
              <div className="generating-icon">
              <span className="as_web_icon-018-html" />
              </div>
              <div className="generating-cap">
                <h4>Full Stack Development</h4>
                <p>
                  Ageskill provides mobile responsive full-stack development
                  services with database management.
                </p>
              </div>
            </div>
          </div>
          <div className="col-lg-6 col-md-6">
            <div className="single-generating d-flex mb-30">
              <div className="generating-icon">
              <span className="as_web_icon-004-coding" />
               
              </div>
              <div className="generating-cap">
                <h4>Wordpress Websites</h4>
                <p>
                  We play with WordPress themes and plugins very easily. We are
                  familiar with all page builders.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* Generating End */}
    {/*Choose Best start*/}
    <div className="choose-best choose-padding">
      <div className="container">
        {/* Section-tittle */}
        <div className="row d-flex justify-content-center">
          <div className="col-lg-7">
            <div className="section-tittle text-center">
              <h2>Our Most Popular Pricing Plan </h2>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-4 col-md-6">
            <div className="single-choose text-center mb-30">
              <div className="do-icon">
              <span  className="as_web_icon-024-planning"></span>
              </div>
              <div className="do-caption">
              <h3>Startup Plan</h3>
                <h4>₹ 9,999</h4>
                <ul>
                  <li>Free Domain Registration</li>
                  <li>One Year Web Hosting</li>
                  <li>Up to 5 Web Pages</li>
                  <li>One Query Form</li>
                  <li>
                    <div className="do-btn">
                      <b>
                        <a href="#">Get Now</a>
                      </b>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
            <div className="single-choose active text-center mb-30">
              <div className="do-icon">
                <span  className="flaticon-award"></span>
                <h3>Advance Plan</h3>
              </div>
              <div className="do-caption">
                <h4>₹ 14,999</h4>
                <ul>
                  <li>Business Website</li>
                  <li>Basic SEO</li>
                  <li>Blogging Page</li>
                  <li>One Month Maintenance</li>
                  <li>
                    <div className="do-btn">
                      <b>
                        <a href="#">Get Now</a>
                      </b>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
            <div className="single-choose text-center mb-30">
              <div className="do-icon">
              <span  className="as_web_icon-034-online-shop"></span>
              </div>
              <div className="do-caption">
              <h3>Premium Plan</h3>
                <h4>₹ 24,999</h4>
                <ul>
                  <li>E-commerce Website</li>
                  <li>Basic SEO</li>
                  <li>Unlimited Product Pages</li>
                  <li>Two Month Maintenance</li>
                  <li>
                    <div className="do-btn">
                      <b>
                        <a href="#">Get Now</a>
                      </b>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    {/* Choose Best do End*/}
    {/* Visit Stuffs Start */}
    <div className="visit-area fix visite-padding">
      <div className="container">
        {/* Section-tittle */}
        <div className="row d-flex justify-content-center">
          <div className="col-lg-6 pr-0">
            <div className="section-tittle text-center">
              <h2>Some New Stuffs From Digital Marketing</h2>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid p-0">
        <div className="row ">
          <div className="col-lg-3 col-md-4">
            <div className="single-visited mb-30">
              <div className="visited-img">
                <img src={digoptimg} alt />
              </div>
              <div className="visited-cap">
                <h3>
                  <a href="#">Optimization</a>
                </h3>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-md-4">
            <div className="single-visited mb-30">
              <div className="visited-img">
                <img src={digseoimg} alt />
              </div>
              <div className="visited-cap">
                <h3>
                  <a href="#">SEO Service</a>
                </h3>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-md-4">
            <div className="single-visited mb-30">
              <div className="visited-img">
                <img src={diganaimg} alt />
              </div>
              <div className="visited-cap">
                <h3>
                  <a href="#">Analytics</a>
                </h3>
              </div>
            </div>
          </div>
          <div className="col-lg-3 col-md-4">
            <div className="single-visited mb-30">
              <div className="visited-img">
                <img src={diglinkgimg} alt />
              </div>
              <div className="visited-cap">
                <h3>
                  <a href="#">Link Building</a>
                </h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* Visit Stuffs Start */}
    {/* Testimonial Start */}
    
    {/* Testimonial End */}
    {/* Tips Triks Start */}
    <Testimonial />
    <HomeBlog/>
    {/* Tips Triks End */}
    {/* have-project Start*/}
    <div className="have-project">
      <div className="container">
        <div
          className="haveAproject"
        style={{backgroundImage: `url(${subscribeimg})`}} >
          <div className="row d-flex align-items-center">
            <div className="col-xl-7 col-lg-9 col-md-12">
              <div className="wantToWork-caption">
                <h2>Promote your business</h2>
                <p>
                  Connect with us and get your URL to promote your business
                  online without any cost. Offer for a limited time only.
                </p>
              </div>
            </div>
            <div className="col-xl-5 col-lg-3 col-md-12">
              <div className="wantToWork-btn f-right">
                <a
                  href="https://remotework.ageskill.net/registration-to-promote-your-business/"
                  className="btn btn-ans"
                target="blank">
                  Subscribe Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* have-project End */}
  </main>
    </div>
  )
}
