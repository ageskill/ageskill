import React from 'react'
import logo from '../assets/img/ageskill.png';
import { BrowserRouter as Router, Route, Link, Switch} 
        from "react-router-dom";


export default function Navbar() {
  return (
    <div>
   
        <header>
    {/* Header Start */}
    <div className="header-area header-transparrent ">
      <div className="main-header header-sticky">
        <div className="container">
          <div className="row align-items-center">
            {/* Logo */}
            <div className="col-xl-2 col-lg-2 col-md-1">
              <div className="logo">
              <Link to="/">
                  <img src={logo} alt="ageskill logo" style={{ width: "80%" }}/>
                </Link>
              </div>
            </div>
            <div className="col-xl-8 col-lg-8 col-md-8">
              {/* Main-menu */}
              <div className="main-menu f-right d-none d-lg-block">
                <nav>
        
          <ul id="navigation">
            <li><Link to="/">Home</Link></li>
            <li><Link to="service">Service</Link></li>
            <li><Link to="pricing">Pricing</Link></li>
            <li><Link to="blogs">Blogs</Link></li>
            <li><Link to="contact">Contact</Link></li>
          </ul>
          </nav>
              </div>
            </div>
            <div className="col-xl-2 col-lg-2 col-md-3">
              <div className="header-right-btn f-right d-none d-lg-block">
                <a
                  href="https://remotework.ageskill.net/my-account/"
                  className="btn header-btn"
                  target="_blank">
                  My Account
                </a>
              </div>
            </div>
            {/* Mobile Menu */}
            <div className="col-12">
              <div className="mobile_menu d-block d-lg-none" />
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* Header End */}
  </header>
     
  </div>
  )
}
