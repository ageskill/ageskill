import React from 'react'
import logo from '../assets/img/ageskill.png';
import ftback from '../assets/img/shape/footer_bg.png';
import { BrowserRouter as Router, Route, Link, Switch} 
        from "react-router-dom";

export default function Footer() {
  return (
    <div>
      <footer>
    {/* Footer Start*/}
    <div
      className="footer-main"
    style={{backgroundImage: `url(${ftback})`, backgroundColor: '#f5f5f5'}}>
      <div className="footer-area footer-padding">
        <div className="container">
          <div className="row d-flex justify-content-between">
            <div className="col-lg-3 col-md-4 col-sm-8">
              <div className="single-footer-caption mb-50">
                <div className="single-footer-caption mb-30">
                  {/* logo */}
                  <div className="footer-logo" id="footer01">
                  <Link to="/">
                    <img src={logo} alt="ageskill logo" style={{ width: "80%" }}/>
                    </Link>
                  </div>
                  <div className="footer-tittle">
                    <div className="footer-pera">
                      <p className="info1">
                        116/117 3rd F, Sector 3, Vaishali <br />
                        Ghaziabad 201010
                      </p>
                      <p className="info2">info@ageskill.net</p>
                    </div>
                  </div>
                  <div className="footer-social">
                    <Link to="https://www.facebook.com/ageskill.net/"
                      id="contact">
                      <i className="fab fa-facebook-f" />
                    </Link>
                    <Link to="https://twitter.com/Ageskill1">
                      <i className="fab fa-twitter" />
                    </Link>
                    <Link to="#">
                      <i className="fas fa-globe" />
                    </Link>
                    <Link to="#">
                      <i className="fab fa-behance" />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-2 col-md-4 col-sm-5">
              <div className="single-footer-caption mb-50">
                <div className="footer-tittle">
                  <h4>Quick Links</h4>
                  <ul>
                    <li>
                      <Link to="/services">Features</Link>
                    </li>
                    <li>
                      <Link to="/pricing">Pricing</Link>
                    </li>
                    <li>
                      <Link to="">Blog</Link>
                    </li>
                    <li>
                      <Link to="/contact">Contact</Link>
                    </li>
                    <li>
                      <Link to="/">
                        Dashboard
                      </Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="col-lg-2 col-md-4 col-sm-7">
              <div className="single-footer-caption mb-50">
                <div className="footer-tittle">
                  <h4>Support</h4>
                  <ul>
                    <li>
                      <Link to="#">Terms &amp; Conditions</Link>
                    </li>
                    <li>
                      <Link to="#">Sitemap</Link>
                    </li>
                    <li>
                      <Link to="/">
                        Promote Business
                      </Link>
                    </li>
                    <li>
                      <Link to="/">Remote Jobs</Link>
                    </li>
                    <li>
                      <Link to="#">24/7 Support</Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="col-lg-3 col-md-4 col-sm-5">
              <div className="single-footer-caption mb-50">
                <div className="footer-tittle">
                  <h4>Core Features</h4>
                  <ul>
                    <li>
                      <Link to="#"> Offline SEO</Link>
                    </li>
                    <li>
                      <Link to="#">Social Media Marketing</Link>
                    </li>
                    <li>
                      <Link to="#">Lead Generation</Link>
                    </li>
                    <li>
                      <Link to="#"> Website Maintenance</Link>
                    </li>
                    <li>
                      <Link to="#"> Management Service</Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* footer-bottom aera */}
      <div className="footer-bottom-area footer-bg">
        <div className="container">
          <div className="footer-border">
            <div className="row d-flex align-items-center">
              <div className="col-xl-12 ">
                <div className="footer-copy-right text-center">
                  <p>
                    {/* Link back to Ageskill can't be removed. Template is licensed under CC BY 3.0. */}
                    Copyright © | All rights reserved{" "}
                    <i className="ti-heart" aria-hidden="true" /> by{" "}
                    <Link to="/" target="_blank">
                      Ageskill
                    </Link>
                    {/* Link back to Ageskill can't be removed. Template is licensed under CC BY 3.0. */}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* Footer End*/}
  </footer>
    </div>
  )
}
