
import React, { useState } from 'react'
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import { BrowserRouter as Router, Route, Switch, withRouter} 
        from "react-router-dom";
        import Service from './components/Service';
        import Home  from  "./components/Home.js"
        import Price  from   './components/Price.js';
        import Blogs  from   './components/Blogs';
        import Contact from   './components/Contact'

function App() {
  
  return (
   <div>
    
    <Router>
   
    <Navbar/>
        <Switch>
          <Route exact path="/" component={withRouter(Home)} />
          <Route exact path="/service" component={withRouter(Service)} />
          <Route exact path="/pricing" component={withRouter(Price)} />
          <Route exact path="/blogs" component={withRouter(Blogs)} />
          <Route exact path="/contact" component={withRouter(Contact)} />
        </Switch>
  {/* CSS here */}
  {/*?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Max-Age: 1000");
header("Access-Control-Allow-Headers: X-Requested-With, Content-Type, Origin, Cache-Control, Pragma, Authorization, Accept, Accept-Encoding");
header("Access-Control-Allow-Methods: PUT, POST, GET, OPTIONS, DELETE");
?*/}
  <style
    dangerouslySetInnerHTML={{
      __html:
        "\n         img.attachment-ageskill-recent-thumbnails.size-ageskill-recent-thumbnails.wp-post-image {\n    height: 200px;\n}\n     ",
    }}
  />
 <Footer />
</Router>

</div>

  );

}

export default App;